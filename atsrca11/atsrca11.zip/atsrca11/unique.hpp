// [unique.hpp]
// (C) Copyright 2003 Michael Blackney
#if !defined ( UNIQUE_HPP )
#define UNIQUE_HPP

#endif // UNIQUE_HPP
