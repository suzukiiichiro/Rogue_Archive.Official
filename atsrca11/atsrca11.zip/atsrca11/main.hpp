// [main.hpp]
// (C) Copyright 2000-2002 Michael Blackney
#if !defined ( MAIN_HPP )
#define MAIN_HPP

#endif // MAIN_HPP
