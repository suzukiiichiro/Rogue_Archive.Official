// [misc.hpp]
// (C) Copyright 2000-2002 Michael Blackney
#if !defined ( MISC_HPP )
#define MISC_HPP

#include "string.hpp"
#include "list.hpp"
#include "target.hpp"

String describeList( List<Target> );

#endif // MISC_HPP
