// [itemlist.hpp]
// (C) Copyright 2000-2002 Michael Blackney
#if !defined ( ITEMLIST_HPP )
#define ITEMLIST_HPP

#endif // ITEMLIST_HPP
