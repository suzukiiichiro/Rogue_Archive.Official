rm -f *.o moria.exe
rm -rf dist/
