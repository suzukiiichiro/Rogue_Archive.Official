package crl.ui;

public class ActionCancelException extends Exception{


}