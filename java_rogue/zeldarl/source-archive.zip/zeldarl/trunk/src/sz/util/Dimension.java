package sz.util;

public class Dimension {
	public int x, y;

	public int getArea(){
		return x*y;
 	}
}