package sz.csi.textcomponents;

import crl.ui.Appearance;

public interface MenuItem extends java.io.Serializable{
	public char getMenuChar();
	public int getMenuColor();
	public String getMenuDescription();

}