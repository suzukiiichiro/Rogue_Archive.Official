package sz.csi.textcomponents;

public interface ListItem extends java.io.Serializable {
		
	public char getIndex();
	public int getIndexColor();
	public String getRow();
}
