Legend of Zelda, the Rainbow Maiden
Version 0.72a

Made by Slash for the 2007 7DRL contest initially.

A manual will come with time, for now visit the official website for further info

http://www.santiagoz.com/web

Happy questing!