#ifndef MACHEADERS
#define MACHEADERS


#define TOPSCO

#include <Carbon/Carbon.h>
#include	<stdio.h>
#include	<stdlib.h>
#include	<string.h>

#ifdef __MWERKS__
extern long _fcreator;
extern long _ftype;
#endif
#endif