/*
 * random.h
 *
 * Created by Ashwin N.
 */

#ifndef _RANDOM_H_
#define _RANDOM_H_

int get_rand(int x, int y);

int rand_percent(int percentage);

int coin_toss(void);

#endif	/* _RANDOM_H_ */
