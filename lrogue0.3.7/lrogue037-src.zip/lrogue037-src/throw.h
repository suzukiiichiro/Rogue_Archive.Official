/*
 * throw.h
 *
 * Created by Ashwin N.
 */

#ifndef _THROW_H_
#define _THROW_H_

void throw(void);

void rand_around(short i, short *r, short *c);

#endif	/* _THROW_H_ */
