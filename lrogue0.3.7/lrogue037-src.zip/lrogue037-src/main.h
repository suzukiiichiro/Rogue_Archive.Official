/*
 * main.h
 *
 * Created by Ashwin N.
 */

#ifndef _MAIN_H_
#define _MAIN_H_

/*void turn_into_games(void);

void turn_into_user(void);*/

#endif	/* _MAIN_H_ */
