/*
 * instruct.h
 *
 * Created by Ashwin N.
 */

#ifndef _INSTRUCT_H_
#define _INSTRUCT_H_

void Instructions(void);

#endif	/* _INSTRUCT_H_ */
