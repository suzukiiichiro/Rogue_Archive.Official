/*
 * zap.h
 *
 * Created by Ashwin N.
 */

#ifndef _ZAP_H_
#define _ZAP_H_

void zapp(void);

void zap_monster(object *monster, unsigned short kind);

void wizardize(void);

#endif	/* _ZAP_H_ */
