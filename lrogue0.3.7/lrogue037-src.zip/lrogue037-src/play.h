/*
 * play.h
 *
 * Created by Ashwin N.
 */

#ifndef _PLAY_H_
#define _PLAY_H_

void play_level(void);

#endif	/* _PLAY_H_ */
