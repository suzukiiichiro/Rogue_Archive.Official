/* omega copyright (C) by Laurence Raphael Brothers, 1987,1988,1989 */
/* date.h */

#define LAST_OMEGA_EDIT_DATE "Thu Jun 30 14:12:52 EST 1994"
