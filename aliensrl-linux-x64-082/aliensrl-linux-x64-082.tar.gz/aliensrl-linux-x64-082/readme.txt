======================================================================
 AliensRL 0.8.2 version
======================================================================

I am proud to present AliensRL, my entry for the 2007 March 7DRL 
competition. Although I didn't manage to implement all that I wanted 
into the game, I still think it satisfies the "playability" requirement, 
and also is in it's own way unique.

I could write a lot about it's development and design features, but why
not try it yourself?

  The game's website  : http://alien.chaosforge.org/
  The game's forum    : http://forum.chaosforge.org/
  ChaosForge Facebook : http://www.facebook.com/ChaosForge
  ChaosForge Google+  : http://gplus.to/ChaosForge
  ChaosForge Twitter  : http://twitter.com/chaosforge_org

If you like the direction in which this roguelike is heading, please
consider making a donation in support of it's further development,
or drop by the forum to share your opinions on it!

Anyway, enough chitchat, play the game, dammit! ;]

                                            Kornel Kisielewicz
                                            admin@chaosforge.org
                                            http://chaosforge.org

=============================================================================

All the help needed is available online by pressing "ESCAPE", or reading the
manual.txt. You can change the keybindings in the config.lua file. Also after
death a file called "mortem.txt" is created -- you can post it on the forum
or the newsgroups :)

In config.lua you can also change the dimensions of the screen, both in 
console mode as well as pseudo-console (note however, that Windows has wierd
requirements for console, so not all combinations work).

There's still a lot planned for AliensRL and we will be rolling out more and
more features as time passes. Major features planned:

        -- many tower features, like terminals and special rooms
        -- security and military tower with rogue security bots
        -- taking over cameras and security bots
        -- hacking the terminals to manage energy flow or locking corridors
        -- a general Master AI (Queen) that fights the player
        -- several objectives and many ways to finish the game
        -- tower structure requiring tactical planning
        -- a more sinister and scary mood
        -- much, much more!

=============================================================================

Credits

DaEezT -- the biggest thanks to him - the co-designer of AliensRL, without
you there would be no AliensRL :)
GenTechJ -- for great help in finding most of the audio files
Fingerzam, Malek, BDR, RickVoid, Styro and all people that helped on the
design of AliensRL.
skarczew -- for being the most loyal AliensRL beta tester.
Donators -- without you I would have no hope of making game design my major
life goal, and you guys push me forward!
Chaosforge forum -- without you people I wouldn't be bothering :).

=============================================================================

Audio files

abta.mod -- the main theme from Alien Breed: Tower Assault by Team 17
music and sound -- James Tubbrit (www.irishacts.com) and Tim Alder taken from
  FXHome.com, others I don't remember (CC 3.0 Licence)
voice -- Crystal (Synthesized Voice) AT&T labs ( http://www.research.att.com/ )
  with apologies

=============================================================================

AliensRL is distributed in the hope that it will be fun, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE.

=============================================================================

